#ifndef CONSTANTS_H
#define CONSTANTS_H

// #define MAX_BK_SIZE 10

#define TRUE 1
#define FALSE 0

#endif